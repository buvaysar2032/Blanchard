---
name: ✨ Feature request
about: Suggest a feature
title: ''
labels: "\U0001F48E enhancement"
assignees: ''
---

## Problem

A clear and concise description of what the problem is.

## Solution

A clear and concise description of what you want to happen.
